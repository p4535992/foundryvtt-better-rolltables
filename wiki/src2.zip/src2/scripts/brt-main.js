import { BetterRolltableHooks } from './hooks/init.js';

BetterRolltableHooks.init();
